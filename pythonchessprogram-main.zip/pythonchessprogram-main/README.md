# pythonchessprogram
Very scuffed python chess program I made for a high school project

## Missing features:
- Preventing castling when tiles on path are under attack by opposing pieces
- Preventing castling when king is in check
- En passant
- Organization lul
