let Person ;
Person = ["victor", "david", "samuel"];
console.log(Person);

function appendNewPerson() {
    Person.push("mubarak");
}
appendNewPerson();